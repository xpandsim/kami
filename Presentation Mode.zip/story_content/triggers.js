function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5uFH3HonzrF":
        Script1();
        break;
      case "6SPCXubY816":
        Script2();
        break;
      case "61obkWhrLUY":
        Script3();
        break;
      case "5pvdCdvd0mJ":
        Script4();
        break;
      case "6N63YLlzTZo":
        Script5();
        break;
      case "69530nILIu6":
        Script6();
        break;
      case "6eFOGpMQBHx":
        Script7();
        break;
      case "6EpUwzgXUUX":
        Script8();
        break;
      case "6MwqBLB2iS3":
        Script9();
        break;
      case "5e1ij0KqDSH":
        Script10();
        break;
      case "6jmsCNVbrQB":
        Script11();
        break;
      case "5lSfDwEjRam":
        Script12();
        break;
      case "5ruxawPDL5Z":
        Script13();
        break;
      case "64Ahp5mVieO":
        Script14();
        break;
      case "6DGuznrkxS0":
        Script15();
        break;
      case "5pOELGw8Fir":
        Script16();
        break;
      case "6MbKLN3qOSC":
        Script17();
        break;
      case "5ymtckirfde":
        Script18();
        break;
      case "6g9Pgoes17j":
        Script19();
        break;
      case "6iYNLzc5yaK":
        Script20();
        break;
      case "6iYeTZDkyH4":
        Script21();
        break;
      case "6htoyrHwkZF":
        Script22();
        break;
      case "69YklePR1ps":
        Script23();
        break;
      case "6ezgEoCNAEF":
        Script24();
        break;
      case "6jY52LwmVDH":
        Script25();
        break;
      case "6XOkdytEh2v":
        Script26();
        break;
      case "5ojp3PfDGYW":
        Script27();
        break;
      case "6ZLxjTLYdeG":
        Script28();
        break;
      case "60IdOMhwMdt":
        Script29();
        break;
      case "5eL5kvyzLkL":
        Script30();
        break;
      case "6pHswmVDboI":
        Script31();
        break;
      case "6adk2kf3CX5":
        Script32();
        break;
      case "5yRPUAoxgis":
        Script33();
        break;
      case "6nBhFlxUE8k":
        Script34();
        break;
      case "6F3qhRpSJqb":
        Script35();
        break;
      case "6CWcxOkzjcK":
        Script36();
        break;
      case "5VBXMPnfRNn":
        Script37();
        break;
      case "5kFxGEsAazE":
        Script38();
        break;
      case "6DSKGN96RHS":
        Script39();
        break;
      case "6CoaLktpHCI":
        Script40();
        break;
      case "6hWIiVBkYep":
        Script41();
        break;
      case "6PJJDCARruc":
        Script42();
        break;
      case "6UUGwNVVs2m":
        Script43();
        break;
      case "67QanxIAdCi":
        Script44();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
window.Script1 = function()
{
  player.once(() => {
const target = object('6WrfP2prYM1');
const duration = 750;
const easing = 'ease-out';
const id = '660EPnh7waW';
const shakeAmount = 2;
const delay = 1750;
addToTimeline(
target.animate([
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' }
],
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script2 = function()
{
  player.once(() => {
const target = object('6SmYS07pikm');
const duration = 750;
const easing = 'ease-out';
const id = '64ARbLErbd0';
const shakeAmount = 2;
const delay = 1500;
addToTimeline(
target.animate([
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' }
],
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script3 = function()
{
  player.once(() => {
const target = object('5hXFFeYWfrX');
const duration = 750;
const easing = 'ease-out';
const id = '64ARbLErbd0';
const shakeAmount = 2;
const delay = 1000;
addToTimeline(
target.animate([
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' }
],
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script4 = function()
{
  player.once(() => {
const target = object('634WPj4iaJR');
const duration = 750;
const easing = 'ease-out';
const id = '64ARbLErbd0';
const shakeAmount = 2;
const delay = 1000;
addToTimeline(
target.animate([
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' }
],
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script5 = function()
{
  player.once(() => {
const target = object('6dtKBilKxV5');
const duration = 750;
const easing = 'ease-out';
const id = '6cEFQ7rCwcQ';
const shakeAmount = 2;
const delay = 12500;
addToTimeline(
target.animate([
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' }
],
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script6 = function()
{
  player.once(() => {
const target = object('6B0coG1f4bJ');
const duration = 750;
const easing = 'ease-out';
const id = '5YlTJqVyhS3';
const shakeAmount = 2;
const delay = 16000;
addToTimeline(
target.animate([
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' }
],
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script7 = function()
{
  player.once(() => {
const target = object('5eZLAlLG7xy');
const duration = 750;
const easing = 'ease-out';
const id = '5oZJNJdydw5';
const shakeAmount = 2;
const delay = 2250;
addToTimeline(
target.animate([
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' }
],
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script8 = function()
{
  player.once(() => {
const target = object('5pBXoZD4bTB');
const duration = 750;
const easing = 'ease-out';
const id = '5nc9MScHTjl';
const shakeAmount = 2;
const delay = 4000;
addToTimeline(
target.animate([
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' }
],
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script9 = function()
{
  player.once(() => {
const target = object('5Zsi9KnIMra');
const duration = 750;
const easing = 'ease-out';
const id = '6QfJ5KYyUpc';
const shakeAmount = 2;
const delay = 5500;
addToTimeline(
target.animate([
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' }
],
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script10 = function()
{
  player.once(() => {
const target = object('6Yd9QlXT2Ba');
const duration = 750;
const easing = 'ease-out';
const id = '62kimLgKcgY';
const shakeAmount = 2;
const delay = 2250;
addToTimeline(
target.animate([
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' }
],
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script11 = function()
{
  player.once(() => {
const target = object('5a26yswJJ1k');
const duration = 750;
const easing = 'ease-out';
const id = '5nFWmP2a7za';
const shakeAmount = 2;
const delay = 3000;
addToTimeline(
target.animate([
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' }
],
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script12 = function()
{
  player.once(() => {
const target = object('65qbEsXi3Z4');
const duration = 750;
const easing = 'ease-out';
const id = '5ur4WGeEhTF';
const shakeAmount = 2;
const delay = 1250;
addToTimeline(
target.animate([
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' }
],
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script13 = function()
{
  player.once(() => {
const target = object('65CmO9ihnRb');
const duration = 750;
const easing = 'ease-out';
const id = '5kZqcSLwIaz';
const shakeAmount = 2;
const delay = 2771;
addToTimeline(
target.animate([
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' }
],
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script14 = function()
{
  player.once(() => {
const target = object('6cHnMutcO4r');
const duration = 750;
const easing = 'ease-out';
const id = '5npbkW7dZQv';
const shakeAmount = 2;
const delay = 6688;
addToTimeline(
target.animate([
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' }
],
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script15 = function()
{
  player.once(() => {
const target = object('5tEbaqwaI5w');
const duration = 1000;
const easing = 'ease-out';
const id = '5mu51FL49aK';
const shakeAmount = 2;
const delay = 1500;
addToTimeline(
target.animate([
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' }
],
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script16 = function()
{
  const target = object('6A5HQcxsnAv');
const duration = 750;
const easing = 'ease-out';
const id = '5xRliLnhwSh';
const shakeAmount = 2;
player.addForTriggers(
id,
target.animate([
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' }
],
  { fill: 'forwards', duration, easing }
)
);
}

};
